package com.example.oauthatividade;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OauthatividadeApplication {

	public static void main(String[] args) {
		SpringApplication.run(OauthatividadeApplication.class, args);
	}

}
